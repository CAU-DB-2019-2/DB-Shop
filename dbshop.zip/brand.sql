--------------------------------------------------------
--  파일이 생성됨 - 수요일-11월-27-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table BRAND
--------------------------------------------------------

  CREATE TABLE "BRAND" 
   (	"BRAND_ID" CHAR(4 BYTE), 
	"BRAND_NAME" VARCHAR2(20 BYTE), 
	"ADDRESS1" VARCHAR2(30 BYTE), 
	"ADDRESS2" VARCHAR2(50 BYTE)
   ) ;
REM INSERTING into BRAND
SET DEFINE OFF;
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0006','구찌','서울특별시 강남구','압구정동 압구정로 343 갤러리아 1층');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0001','나이키','서울특별시 강남구','역삼1동 테헤란로 152');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0003','자라','서울특별시 서초구','서초동 1304-3');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0009','롤렉스','서울특별시 강남구','역삼1동 737');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0011','샤넬','서울특별시 중구','세종대로9길 41, 11층');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0012','로레알','서울특별시 강남구','삼성동 159-1');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0016','넥스트','경기도 광주시','곤지암읍 수양리 120');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0020','랄프로렌','서울특별시 중구','남대문로2가');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0004','아디다스','서울특별시 서초구','서초동 1321-15');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0005','에르메스','서울특별시 중구','장충동2가 202');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0007','루이비통','서울특별시 강남구','삼성동 삼성로 511');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0008','유니클로','서울시특별시 용산구','한강로 3가 40-999 아이파크몰 2층');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0010','에르메스','서울특별시 강남구','도산대로45길 7');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0013','노스페이스','서울특별시 동작구','사당동 1046-8');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0014','코오롱 스포츠','서울특별시 서초구','반포동 737-9');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0015','에스콰이어','서울특별시 중구','을지로1가');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0017','휴고보스','서울특별시 종로구','종로1가 1번지 15층 교보생명빌딩');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0018','타미힐피거','서울특별시 중구','남대문로 81, 04533 서울특별시');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0019','룰루레몬','서울특별시 강남구','선릉로 835, 3층');
Insert into BRAND (BRAND_ID,BRAND_NAME,ADDRESS1,ADDRESS2) values ('0002','H&M','서울특별시 종로구','종로 51, 종로타워 17 층');
--------------------------------------------------------
--  DDL for Index SYS_C007316
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C007316" ON "BRAND" ("BRAND_ID") 
  ;
--------------------------------------------------------
--  Constraints for Table BRAND
--------------------------------------------------------

  ALTER TABLE "BRAND" MODIFY ("BRAND_ID" NOT NULL ENABLE);
  ALTER TABLE "BRAND" MODIFY ("BRAND_NAME" NOT NULL ENABLE);
  ALTER TABLE "BRAND" MODIFY ("ADDRESS1" NOT NULL ENABLE);
  ALTER TABLE "BRAND" MODIFY ("ADDRESS2" NOT NULL ENABLE);
  ALTER TABLE "BRAND" ADD PRIMARY KEY ("BRAND_ID")
  USING INDEX  ENABLE;
