--------------------------------------------------------
--  파일이 생성됨 - 수요일-11월-27-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table STOCK
--------------------------------------------------------

  CREATE TABLE "STOCK" 
   (	"PRODUCT_ID" CHAR(10 BYTE), 
	"SIZE_INFO" VARCHAR2(3 BYTE), 
	"STOCK" NUMBER(*,0)
   ) ;
REM INSERTING into STOCK
SET DEFINE OFF;
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000001','S',12);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000001','M',21);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000001','L',33);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000002','S',22);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000003','260',2);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000004','L',21);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000005','S',12);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000005','L',1);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000006','S',54);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000006','M',22);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000008','S',15);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000009','S',24);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000009','M',22);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000012','M',1);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000012','L',12);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000013','230',6);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000013','270',9);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000015','S',14);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000015','270',15);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000016','L',1);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000017','S',9);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000018','240',12);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000018','250',40);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000018','270',29);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000019','L',38);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000020','S',30);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000003','250',3);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000010','F',23);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000017','F',4);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000011','S',11);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000011','M',7);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000019','XS',18);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000016','F',5);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000007','L',3);
Insert into STOCK (PRODUCT_ID,SIZE_INFO,STOCK) values ('p000000006','L',37);
--------------------------------------------------------
--  DDL for Index SYS_C007334
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C007334" ON "STOCK" ("PRODUCT_ID", "SIZE_INFO") 
  ;
--------------------------------------------------------
--  Constraints for Table STOCK
--------------------------------------------------------

  ALTER TABLE "STOCK" MODIFY ("PRODUCT_ID" NOT NULL ENABLE);
  ALTER TABLE "STOCK" MODIFY ("SIZE_INFO" NOT NULL ENABLE);
  ALTER TABLE "STOCK" MODIFY ("STOCK" NOT NULL ENABLE);
  ALTER TABLE "STOCK" ADD PRIMARY KEY ("PRODUCT_ID", "SIZE_INFO")
  USING INDEX  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table STOCK
--------------------------------------------------------

  ALTER TABLE "STOCK" ADD FOREIGN KEY ("PRODUCT_ID")
	  REFERENCES "PRODUCT" ("PRODUCT_ID") ENABLE;
