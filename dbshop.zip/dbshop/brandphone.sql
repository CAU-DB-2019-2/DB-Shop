--------------------------------------------------------
--  파일이 생성됨 - 수요일-11월-27-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table BRAND_PHONE
--------------------------------------------------------

  CREATE TABLE "BRAND_PHONE" 
   (	"BRAND_ID" CHAR(4 BYTE), 
	"PHONE_NUMBER" VARCHAR2(13 BYTE)
   ) ;
REM INSERTING into BRAND_PHONE
SET DEFINE OFF;
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0001','02-338-3316');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0002','070-4048-5375');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0003','02-511-7288');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0004','070-4063-4692');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0005','02-2231-2593');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0006','02-2015-6000');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0007','02-338-9085');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0008','010-8214-9287');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0009','02-337-1987');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0010','02-3478-7250');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0011','02-579-6467');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0012','02-542-6267');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0013','02-6366-3078');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0014','070-8615-3800');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0015','070-7721-2995');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0016','070-8222-4501');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0017','070-7714-7005');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0018','02-6954-0157');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0019','070-8254-1123');
Insert into BRAND_PHONE (BRAND_ID,PHONE_NUMBER) values ('0020','02-1661-0612');
--------------------------------------------------------
--  DDL for Index SYS_C007319
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C007319" ON "BRAND_PHONE" ("BRAND_ID", "PHONE_NUMBER") 
  ;
--------------------------------------------------------
--  Constraints for Table BRAND_PHONE
--------------------------------------------------------

  ALTER TABLE "BRAND_PHONE" MODIFY ("BRAND_ID" NOT NULL ENABLE);
  ALTER TABLE "BRAND_PHONE" MODIFY ("PHONE_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "BRAND_PHONE" ADD PRIMARY KEY ("BRAND_ID", "PHONE_NUMBER")
  USING INDEX  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table BRAND_PHONE
--------------------------------------------------------

  ALTER TABLE "BRAND_PHONE" ADD FOREIGN KEY ("BRAND_ID")
	  REFERENCES "BRAND" ("BRAND_ID") ENABLE;
