--------------------------------------------------------
--  파일이 생성됨 - 수요일-11월-27-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table USER_PHONE
--------------------------------------------------------

  CREATE TABLE "USER_PHONE" 
   (	"USER_ID" CHAR(7 BYTE), 
	"PHONE_NUMBER" VARCHAR2(13 BYTE)
   ) ;
REM INSERTING into USER_PHONE
SET DEFINE OFF;
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000001','010-1234-1234');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000002','010-1234-1234');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000003','070-0182-0230');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000004','010-2321-2321');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000005','010-4632-1421');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000006','070-5454-4522');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000007','010-3535-5335');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000008','010-7363-6226');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000009','010-3525-1553');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000010','010-5225-1515');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000011','010-2322-5252');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000012','010-7723-3412');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000013','010-4241-2315');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000014','010-2241-4421');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000015','010-9912-1422');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000016','010-2251-2341');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000017','010-2259-8471');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000018','010-5551-2412');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000019','010-2483-0532');
Insert into USER_PHONE (USER_ID,PHONE_NUMBER) values ('0000020','010-2419-3127');
--------------------------------------------------------
--  DDL for Index SYS_C007310
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C007310" ON "USER_PHONE" ("USER_ID", "PHONE_NUMBER") 
  ;
--------------------------------------------------------
--  Constraints for Table USER_PHONE
--------------------------------------------------------

  ALTER TABLE "USER_PHONE" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "USER_PHONE" MODIFY ("PHONE_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "USER_PHONE" ADD PRIMARY KEY ("USER_ID", "PHONE_NUMBER")
  USING INDEX  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table USER_PHONE
--------------------------------------------------------

  ALTER TABLE "USER_PHONE" ADD FOREIGN KEY ("USER_ID")
	  REFERENCES "USER_INFO" ("USER_ID") ENABLE;
