--------------------------------------------------------
--  파일이 생성됨 - 수요일-11월-27-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ORDER_PHONE
--------------------------------------------------------

  CREATE TABLE "ORDER_PHONE" 
   (	"ORDER_ID" CHAR(8 BYTE), 
	"PHONE_NUMBER" VARCHAR2(13 BYTE)
   ) ;
REM INSERTING into ORDER_PHONE
SET DEFINE OFF;
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111111','010-1234-1234');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111112','010-0000-0000');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111112','070-0182-0230');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111113','010-2321-2321');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111114','010-4632-1421');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111114','070-5454-4522');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111115','010-3535-5335');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111116','010-7363-6226');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111117','010-3525-1553');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111118','010-5225-1515');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111119','010-4637-4637');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111120','010-2366-5235');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111121','010-3255-1555');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111122','011-1535-1531');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111123','010-3535-2515');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111124','010-7564-8564');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111125','010-2352-7568');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111126','010-2646-2644');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111127','010-8658-3763');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111128','010-2754-2744');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111129','010-7800-5070');
Insert into ORDER_PHONE (ORDER_ID,PHONE_NUMBER) values ('11111130','010-6334-3759');
--------------------------------------------------------
--  DDL for Index SYS_C007347
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C007347" ON "ORDER_PHONE" ("ORDER_ID", "PHONE_NUMBER") 
  ;
--------------------------------------------------------
--  Constraints for Table ORDER_PHONE
--------------------------------------------------------

  ALTER TABLE "ORDER_PHONE" MODIFY ("ORDER_ID" NOT NULL ENABLE);
  ALTER TABLE "ORDER_PHONE" MODIFY ("PHONE_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "ORDER_PHONE" ADD PRIMARY KEY ("ORDER_ID", "PHONE_NUMBER")
  USING INDEX  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ORDER_PHONE
--------------------------------------------------------

  ALTER TABLE "ORDER_PHONE" ADD FOREIGN KEY ("ORDER_ID")
	  REFERENCES "ORDER_INFO" ("ORDER_ID") ENABLE;
