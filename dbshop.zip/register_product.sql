--------------------------------------------------------
--  파일이 생성됨 - 수요일-11월-27-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table REGISTER_PRODUCT
--------------------------------------------------------

  CREATE TABLE "REGISTER_PRODUCT" 
   (	"BRAND_ID" CHAR(4 BYTE), 
	"PRODUCT_ID" CHAR(10 BYTE), 
	"REGISTER_DATE" DATE
   ) ;
REM INSERTING into REGISTER_PRODUCT
SET DEFINE OFF;
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0001','p000000001',to_date('18/05/11','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0001','p000000002',to_date('18/06/23','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0001','p000000003',to_date('18/09/01','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0002','p000000004',to_date('18/12/28','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0003','p000000005',to_date('19/01/02','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0004','p000000006',to_date('19/01/25','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0005','p000000007',to_date('19/02/10','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0005','p000000008',to_date('19/03/17','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0005','p000000009',to_date('19/04/04','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0005','p000000010',to_date('19/05/01','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0005','p000000011',to_date('19/06/07','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0006','p000000012',to_date('19/06/18','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0007','p000000013',to_date('19/07/25','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0008','p000000014',to_date('19/07/30','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0009','p000000015',to_date('19/08/20','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0009','p000000016',to_date('19/09/08','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0009','p000000017',to_date('19/09/21','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0010','p000000018',to_date('19/10/06','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0011','p000000019',to_date('19/11/17','RR/MM/DD'));
Insert into REGISTER_PRODUCT (BRAND_ID,PRODUCT_ID,REGISTER_DATE) values ('0011','p000000020',to_date('19/05/06','RR/MM/DD'));
--------------------------------------------------------
--  DDL for Index SYS_C007357
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C007357" ON "REGISTER_PRODUCT" ("BRAND_ID", "PRODUCT_ID") 
  ;
--------------------------------------------------------
--  Constraints for Table REGISTER_PRODUCT
--------------------------------------------------------

  ALTER TABLE "REGISTER_PRODUCT" MODIFY ("BRAND_ID" NOT NULL ENABLE);
  ALTER TABLE "REGISTER_PRODUCT" MODIFY ("PRODUCT_ID" NOT NULL ENABLE);
  ALTER TABLE "REGISTER_PRODUCT" MODIFY ("REGISTER_DATE" NOT NULL ENABLE);
  ALTER TABLE "REGISTER_PRODUCT" ADD PRIMARY KEY ("BRAND_ID", "PRODUCT_ID")
  USING INDEX  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table REGISTER_PRODUCT
--------------------------------------------------------

  ALTER TABLE "REGISTER_PRODUCT" ADD FOREIGN KEY ("BRAND_ID")
	  REFERENCES "BRAND" ("BRAND_ID") ENABLE;
  ALTER TABLE "REGISTER_PRODUCT" ADD FOREIGN KEY ("PRODUCT_ID")
	  REFERENCES "PRODUCT" ("PRODUCT_ID") ENABLE;
