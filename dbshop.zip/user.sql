--------------------------------------------------------
--  파일이 생성됨 - 수요일-11월-27-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table USER_INFO
--------------------------------------------------------

  CREATE TABLE "USER_INFO" 
   (	"USER_ID" CHAR(7 BYTE), 
	"USER_NAME" VARCHAR2(10 BYTE), 
	"USER_PASSWORD" VARCHAR2(15 BYTE), 
	"BIRTH" DATE, 
	"GENDER" CHAR(1 BYTE), 
	"USER_RANK" VARCHAR2(6 BYTE), 
	"ADDRESS1" VARCHAR2(30 BYTE), 
	"ADDRESS2" VARCHAR2(50 BYTE)
   ) ;
REM INSERTING into USER_INFO
SET DEFINE OFF;
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000001','김진아','2468kjazz',to_date('92/05/23','RR/MM/DD'),'F','Silver','경상북도 구미시','도량동 그린빌 아파트 204동 1502호');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000002','이주성','2345ljshaha',to_date('91/04/21','RR/MM/DD'),'M','Gold','서울특별시 동작구','상도동 래미안아파트 105동 1201호');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000003','임준하','874ljhbb',to_date('88/03/15','RR/MM/DD'),'M','VIP','서울특별시 강남구','삼성동 중앙하이츠 빌리지 301동 203호');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000005','정현아','429jharere',to_date('97/12/24','RR/MM/DD'),'F','Silver','대전광역시 대덕구','대화동 두레아파트 102동 511호');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000006','임정아','953lzadindin',to_date('00/01/04','RR/MM/DD'),'F','Silver','대전광역시 동구','신흥동 주공아파트 402동 602호');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000007','조현주','928jhjbalbal',to_date('94/06/03','RR/MM/DD'),'F','Gold','경기도 과천시','중앙동 에코팰리스 아파트 501동 1102호');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000008','박지선','492pjskoko',to_date('99/03/29','RR/MM/DD'),'F','Gold','부산광역시 기장군','기장읍 이진캐스빌블루 101동 406호');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000009','이재민','391ljmbakbak',to_date('89/11/05','RR/MM/DD'),'M','VIP','경상남도 김해시','부영동 부영e-그린아파트 401동 1301호');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000010','오병환','195obhkeekee',to_date('86/08/12','RR/MM/DD'),'M','VIP','강원도 원주시','단계동 단계현진 504동 608호');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000011','최승훈','129cshbanban',to_date('99/02/22','RR/MM/DD'),'M','VVIP','경상북도 포항시','지곡동 제철아프트 203동 1103호');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000013','이규상','018lklgalgal',to_date('95/04/28','RR/MM/DD'),'M','Gold','부산광역시','반여동 1316번지');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000014','박영희','928pyhweiwei',to_date('91/05/30','RR/MM/DD'),'F','Gold','대전광역시','유성구 대학로 291');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000015','함원준','838hjwhah',to_date('93/09/15','RR/MM/DD'),'M','VIP','충청북도 청주시','서원구 남사로 7번길 14-2');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000016','전상우','958jskbaba',to_date('95/09/14','RR/MM/DD'),'M','VVIP','세종특별시','한누리대로 어진동 499');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000017','송나은','825snugaga',to_date('96/07/30','RR/MM/DD'),'F','Silver','대구광역시','서구 평리5동 국채보상로43길');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000018','김희성','952khsbubu',to_date('98/04/15','RR/MM/DD'),'M','Silver','광주광역시','광산구 목련로273번길 76');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000019','배민수','359bnstata',to_date('95/08/16','RR/MM/DD'),'M','Silver','경기도 고양시','일산서구 일산로612');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000020','배민수','853seklele',to_date('00/02/02','RR/MM/DD'),'F','Gold','경기도 파주시','파평면 두포리 121');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000004','이정민','394ljmzizi',to_date('95/05/12','RR/MM/DD'),'F','VVIP','충청북도 제천시','모산동 로즈웰힐아파트 201동 507호');
Insert into USER_INFO (USER_ID,USER_NAME,USER_PASSWORD,BIRTH,GENDER,USER_RANK,ADDRESS1,ADDRESS2) values ('0000012','신현주','182shjseisei',to_date('01/08/04','RR/MM/DD'),'M','Silver','경기도 수원시','팔달구 매산로1가 아이메카 201 - 302');
--------------------------------------------------------
--  DDL for Index SYS_C007307
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS_C007307" ON "USER_INFO" ("USER_ID") 
  ;
--------------------------------------------------------
--  Constraints for Table USER_INFO
--------------------------------------------------------

  ALTER TABLE "USER_INFO" MODIFY ("USER_ID" NOT NULL ENABLE);
  ALTER TABLE "USER_INFO" MODIFY ("USER_NAME" NOT NULL ENABLE);
  ALTER TABLE "USER_INFO" MODIFY ("USER_PASSWORD" NOT NULL ENABLE);
  ALTER TABLE "USER_INFO" MODIFY ("BIRTH" NOT NULL ENABLE);
  ALTER TABLE "USER_INFO" MODIFY ("GENDER" NOT NULL ENABLE);
  ALTER TABLE "USER_INFO" MODIFY ("USER_RANK" NOT NULL ENABLE);
  ALTER TABLE "USER_INFO" MODIFY ("ADDRESS1" NOT NULL ENABLE);
  ALTER TABLE "USER_INFO" MODIFY ("ADDRESS2" NOT NULL ENABLE);
  ALTER TABLE "USER_INFO" ADD PRIMARY KEY ("USER_ID")
  USING INDEX  ENABLE;
